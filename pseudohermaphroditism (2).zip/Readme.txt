
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█▄─▄▄─█─▄▄▄▄█▄─▄▄─█▄─██─▄█▄─▄▄▀█─▄▄─█─█─█▄─▄▄─█▄─▄▄▀█▄─▀█▀─▄██▀▄─██▄─▄▄─█─█─█▄─▄▄▀█─▄▄─█▄─▄▄▀█▄─▄█─▄─▄─█▄─▄█─▄▄▄▄█▄─▀█▀─▄█
██─▄▄▄█▄▄▄▄─██─▄█▀██─██─███─██─█─██─█─▄─██─▄█▀██─▄─▄██─█▄█─███─▀─███─▄▄▄█─▄─██─▄─▄█─██─██─██─██─████─████─██▄▄▄▄─██─█▄█─██
▀▄▄▄▀▀▀▄▄▄▄▄▀▄▄▄▄▄▀▀▄▄▄▄▀▀▄▄▄▄▀▀▄▄▄▄▀▄▀▄▀▄▄▄▄▄▀▄▄▀▄▄▀▄▄▄▀▄▄▄▀▄▄▀▄▄▀▄▄▄▀▀▀▄▀▄▀▄▄▀▄▄▀▄▄▄▄▀▄▄▄▄▀▀▄▄▄▀▀▄▄▄▀▀▄▄▄▀▄▄▄▄▄▀▄▄▄▀▄▄▄▀

Malware name:pseudohermaphroditism.exe
Creation date:6/2/2024
Done date:7:07PM 6/8/2024
Creator:WinMalware
Type:C++
Damage rate: Very Destructive (for non-safety version), very low (ONLY FOR SAFETY VERSION)

This is very dangerous for the non-safety version! 
It will destroy this computer by overwriting MBR and Completely Corrupt Registry Also Corrupt your Harddrive and completelt deletes from your computer!

Btw this is Skidded Malware